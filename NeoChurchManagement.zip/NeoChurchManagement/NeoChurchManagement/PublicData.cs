﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeoChurchManagement
{
    public class PublicData
    {
        public static int roleNo;
        public static string userName;
        public static int userID;
        public static int serviceID;


        
    }
}
