﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NeoChurchManagement
{
    /// <summary>
    /// Interaction logic for EditProfile.xaml
    /// </summary>
    public partial class EditProfile : Window
    {
        NeoChurchManagementEntities church = new NeoChurchManagementEntities();

        public EditProfile()
        {
            InitializeComponent();
            
        }
       

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Close();
        }

        private void OnLoad(object sender, RoutedEventArgs e)
        {
            var userdata = church.users.FirstOrDefault(u => u.UserID == PublicData.userID);
            username.Text = userdata.username;
            password.Text = userdata.password;
            name.Text = userdata.Name;
            phonenumber.Text = userdata.PhoneNumber;
            address.Text = userdata.Address;
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult msg =  MessageBox.Show("Are you sure you want to delete your user? \n Once This process is done It can't be undone", "Status Report", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if(msg == MessageBoxResult.Yes)
            {


                var deleteduser = (from User in church.users
                                  where User.UserID == PublicData.userID
                                  select User).FirstOrDefault();
                church.users.Remove(deleteduser);
                church.SaveChanges();

                MessageBox.Show("User Deleted Successfully\n Logging Out", "Status Report", MessageBoxButton.OK, MessageBoxImage.Information);
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            var modifieddata = church.users.FirstOrDefault(u=>u.UserID == PublicData.userID);
            modifieddata.username = username.Text;
            modifieddata.password = password.Text;
            modifieddata.Name = name.Text;
            modifieddata.PhoneNumber = phonenumber.Text;
            modifieddata.Address = address.Text;
            church.users.Attach(modifieddata);
            church.Entry(modifieddata).State = System.Data.Entity.EntityState.Modified;
            church.SaveChanges();
            MessageBox.Show("Changes done successfully \nLogging Out to apply changes");
            MainWindow main = new MainWindow();
            main.Show();
            this.Hide();
        }
    }
}
