﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NeoChurchManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        NeoChurchManagementEntities entities = new NeoChurchManagementEntities();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var user = entities.users.FirstOrDefault(u => u.username == username.Text);
            if (user != null && user.password == password.Password)
            {
                PublicData.roleNo = user.role;
                PublicData.userName = user.Name;
                PublicData.userID = user.UserID;
                MainMenu menu = new MainMenu();
                menu.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Please Check your Username or Password and try again", "Login Status", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }
    }
}
