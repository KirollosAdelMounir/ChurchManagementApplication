﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace NeoChurchManagement
{

    /// <summary>
    /// Interaction logic for AddMembers.xaml
    /// </summary>
    public partial class AddMembers : Window
    {
        public void Reset()
        {
            name.Text = "";
            dateOfBirth.Text = "";
            phonenumber.Text = "";
            job.Text = "";
            address.Text = "";
        }
        bool IsItNumber(string inputvalue)
        {
            Regex isnumber = new Regex("[^0-9]");
            return !isnumber.IsMatch(inputvalue);
        }
        
        public AddMembers()
        {
            InitializeComponent();
        }

        NeoChurchManagementEntities church = new NeoChurchManagementEntities();

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if(name.Text != "" && dateOfBirth != null && phonenumber.Text != "" && address.Text != "" && job.Text != "")
            {
                if (IsItNumber(phonenumber.Text))
                {
                    var lastmember = church.civilians.OrderByDescending(c => c.CivID).FirstOrDefault();
                    civilian Civilian = new civilian()
                    {
                        CivID = lastmember.CivID+1,
                        Name = name.Text,
                        DateOfBirth = DateTime.Parse(dateOfBirth.Text),
                        PhoneNumber = phonenumber.Text,
                        EmailAddress = address.Text,
                        Job = job.Text
                    };
                    church.civilians.Add(Civilian);
                    church.SaveChanges();
                    MessageBox.Show("Member inserted Successfully", "Status Report", MessageBoxButton.OK, MessageBoxImage.Information);
                    Reset();
                }
                else
                {
                    MessageBox.Show("Enter a valid number", "Error while inserting", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
            }
            else
            {
                MessageBox.Show("Complete the data correctly", "Error while inserting", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainMenu main = new MainMenu();
            main.Show();
            this.Close();
        }
    }
}
