﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NeoChurchManagement
{
    /// <summary>
    /// Interaction logic for MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Window
    {
        NeoChurchManagementEntities church = new NeoChurchManagementEntities();
        public List<service> service { set; get; }

        public MainMenu()
        {
            InitializeComponent();
            name.Content = PublicData.userName;
            switch (PublicData.roleNo)
            {
                case 0:
                    Menu3.Visibility = Visibility.Visible;
                    Menu4.Visibility = Visibility.Visible;
                    break;
                case 1:
                    Menu3.Visibility = Visibility.Visible;
                    break;
            }

            if (PublicData.roleNo == 0 || PublicData.roleNo == 1)
            {
                var item = church.services.ToList();
                service = item;
                DataContext = service;
            }
            else
            {
                var item = church.services.Where(u => u.responsibleID == PublicData.userID).ToList();
                service = item;
                DataContext = service;
            }
        }

        private void servicebox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int serviceid = (int)servicebox.SelectedValue;
            var data = church.services.FirstOrDefault(u => u.serviceID == serviceid);
            var UserResponsible = church.users.FirstOrDefault(u => u.UserID == data.responsibleID);
            if (data != null)
            {
                servicename.Content = data.servicename;
                userresponsible.Content = UserResponsible.Name;
                phonenumber.Content = UserResponsible.PhoneNumber;
                day.Content = data.Day;
                time.Content = data.Time;
                PublicData.serviceID = serviceid;
            }
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            AddMembers members = new AddMembers();
            members.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void Button12_Click(object sender, RoutedEventArgs e)
        {
            AddUsers users = new AddUsers();
            users.Show();
            this.Close();
        }

        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            AddEvent addEvent = new AddEvent();
            addEvent.Show();
            this.Close();
        }

        private void EditProfile_Click(object sender, RoutedEventArgs e)
        {
            EditProfile profile = new EditProfile();
            profile.Show();
            this.Close();
        }
    }
}
