﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NeoChurchManagement
{
    /// <summary>
    /// Interaction logic for AddEvent.xaml
    /// </summary>
    public partial class AddEvent : Window
    {
        public void Reset()
        {
            EventName.Text = "";
            description.Text = "";
            dateofevent.Text = "";
        }

        public AddEvent()
        {
            InitializeComponent();
        }
        NeoChurchManagementEntities church = new NeoChurchManagementEntities();
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            MainMenu mainMenu = new MainMenu();
            mainMenu.Show();
            this.Hide();
        }

        private void SaveEvent_Click(object sender, RoutedEventArgs e)
        {
            var lastEvent = church.Events.OrderByDescending(u => u.EventID).FirstOrDefault();
            if (EventName.Text != "" && dateofevent.Text != "" && description.Text != "")
            {
                Event newEvent = new Event()
                {
                    EventID = lastEvent.EventID + 1,
                    EventName = EventName.Text,
                    userSponsor = PublicData.userID,
                    DateOfEvent = DateTime.Parse(dateofevent.Text),
                    Description = description.Text
                }; if (newEvent.DateOfEvent != null || newEvent.DateOfEvent >= DateTime.Now)
                {
                    church.Events.Add(newEvent);
                    church.SaveChanges();
                    Reset();
                }
                else {
                    MessageBox.Show("Enter the date correctly", "Error while inserting", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                MessageBox.Show("Event Added Successfully", "Status Update", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Enter the data correctly","Error while inserting",MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
