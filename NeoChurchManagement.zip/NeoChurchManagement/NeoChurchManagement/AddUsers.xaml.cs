﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace NeoChurchManagement
{
    /// <summary>
    /// Interaction logic for AddUsers.xaml
    /// </summary>
    public partial class AddUsers : Window
    {
       void Reset()
        {
            username.Text = "";
            password.Text = "";
            name.Text = "";
            phonenumber.Text = "";
            address.Text = "";
        }
       bool IsItNumber(string inputvalue) 
        { 
            Regex isnumber = new Regex("[^0-9]");
            return !isnumber.IsMatch(inputvalue);
        }
        NeoChurchManagementEntities church = new NeoChurchManagementEntities();

        public AddUsers()
        {
            InitializeComponent();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if(username.Text!= "" && password.Text != "" && name.Text != "" && phonenumber.Text != "" && address.Text != "") 
            {
                if (IsItNumber(phonenumber.Text))
                {
                    var lastmember = church.users.OrderByDescending(x => x.UserID).FirstOrDefault();
                    user newUser = new user() {
                        UserID = lastmember.UserID + 1,
                        username = username.Text,
                        password = password.Text,
                        Name = name.Text,
                        role = 3,
                        PhoneNumber = phonenumber.Text,
                        Address = address.Text};
                   
                    church.users.Add(newUser);
                    church.SaveChanges();
                    MessageBox.Show("User inserted Successfully","Status Report",MessageBoxButton.OK,MessageBoxImage.Information);
                    Reset();
                }

                else { MessageBox.Show("Enter a valid number", "Error while inserting", MessageBoxButton.OK, MessageBoxImage.Stop); }
                }
            else
            {
                MessageBox.Show("Complete the data correctly","Error while inserting",MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainMenu main = new MainMenu();
            main.Show();
            this.Close();
        }
    }
}
